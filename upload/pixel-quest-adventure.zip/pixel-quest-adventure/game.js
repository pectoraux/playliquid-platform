/* =====================================================================
   PIXEL QUEST ADVENTURE
   A complete HTML5 canvas platformer.
   Systems: InputManager, Physics, Player, Enemy, Collectible, Level,
            Camera, ParticleSystem, Renderer, UI, Telemetry, Game.
   ===================================================================== */
(function () {
  "use strict";

  /* ------------------------------------------------------------------ *
   * Constants & configuration
   * ------------------------------------------------------------------ */
  const CONFIG = {
    CANVAS_W: 960,
    CANVAS_H: 540,
    // Physics (units are pixels, timestep is fixed at 60fps)
    GRAVITY: 0.8,
    MAX_FALL: 18,
    PLAYER_ACCEL: 0.85,
    PLAYER_MAX_SPEED: 5.4,
    PLAYER_FRICTION: 0.80,
    PLAYER_AIR_FRICTION: 0.94,
    JUMP_VELOCITY: -15.2,
    JUMP_CUT: 0.45,        // velocity multiplier when jump released early
    COYOTE_TIME: 6,        // frames of grace after leaving ledge
    JUMP_BUFFER: 6,        // frames of jump press buffering
    ENEMY_BOUNCE: -11,
    START_LIVES: 3,
    FIXED_DT: 1000 / 60,   // ms per fixed update
    MAX_FRAME_DELTA: 100,
  };

  const STATE = {
    BOOT: "boot",
    START: "start",
    PLAYING: "playing",
    PAUSED: "paused",
    LEVEL_COMPLETE: "level_complete",
    WIN: "win",
    GAME_OVER: "game_over",
  };

  /* ------------------------------------------------------------------ *
   * Utility helpers
   * ------------------------------------------------------------------ */
  const clamp = (v, lo, hi) => (v < lo ? lo : v > hi ? hi : v);
  const lerp = (a, b, t) => a + (b - a) * t;
  const rand = (a, b) => a + Math.random() * (b - a);
  const randInt = (a, b) => Math.floor(rand(a, b + 1));
  const choice = (arr) => arr[Math.floor(Math.random() * arr.length)];

  function aabb(a, b) {
    return (
      a.x < b.x + b.w &&
      a.x + a.w > b.x &&
      a.y < b.y + b.h &&
      a.y + a.h > b.y
    );
  }

  /* ------------------------------------------------------------------ *
   * Telemetry bridge — talks to PlayLiquid parent frame
   * ------------------------------------------------------------------ */
  const Telemetry = {
    send(event, data) {
      try {
        if (window.parent && window.parent !== window) {
          window.parent.postMessage(
            { type: "pl:telemetry", event: event, data: data || {} },
            "*"
          );
        }
      } catch (e) {
        /* sandbox may block — ignore */
      }
    },
  };

  /* ------------------------------------------------------------------ *
   * InputManager
   *   - keyboard (arrows / WASD / space / R / P)
   *   - touch buttons
   *   - PlayLiquid input bridge messages
   *   Exposes a normalized state: { left, right, jump } + edge events
   * ------------------------------------------------------------------ */
  class InputManager {
    constructor() {
      this.left = false;
      this.right = false;
      this.jump = false;
      this.pause = false;

      this._prevJump = false;
      this._jumpPressed = false;   // edge: pressed this frame
      this._pausePressed = false;
      this._restartPressed = false;

      this.hasTouch = this._detectTouch();
      this._bindKeyboard();
      this._bindBridge();
    }

    _detectTouch() {
      return (
        ("ontouchstart" in window) ||
        (navigator.maxTouchPoints && navigator.maxTouchPoints > 0) ||
        window.matchMedia("(hover: none) and (pointer: coarse)").matches
      );
    }

    _bindKeyboard() {
      const set = (code, down) => {
        switch (code) {
          case "ArrowLeft":
          case "KeyA":
            this.left = down;
            break;
          case "ArrowRight":
          case "KeyD":
            this.right = down;
            break;
          case "Space":
          case "ArrowUp":
          case "KeyW":
          case "KeyZ":
          case "KeyJ":
            if (down && !this.jump) this._jumpPressed = true;
            this.jump = down;
            break;
          case "KeyP":
          case "Escape":
            if (down) this._pausePressed = true;
            break;
          case "KeyR":
            if (down) this._restartPressed = true;
            break;
        }
      };

      window.addEventListener("keydown", (e) => {
        // Prevent page scroll on space/arrows during gameplay
        if (
          ["Space", "ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(
            e.code
          )
        ) {
          e.preventDefault();
        }
        set(e.code, true);
      });
      window.addEventListener("keyup", (e) => set(e.code, false));

      // Lose focus -> release keys
      window.addEventListener("blur", () => {
        this.left = this.right = this.jump = false;
      });
    }

    _bindBridge() {
      window.addEventListener("message", (event) => {
        const d = event.data;
        if (!d || d.type !== "pl:input") return;
        const pressed = !!d.pressed;
        switch (d.action) {
          case "LEFT":
            this.left = pressed;
            break;
          case "RIGHT":
            this.right = pressed;
            break;
          case "JUMP":
            if (pressed && !this.jump) this._jumpPressed = true;
            this.jump = pressed;
            break;
          case "PAUSE":
            if (pressed) this._pausePressed = true;
            break;
        }
      });
    }

    /* Called once per fixed update to consume edge events */
    postUpdate() {
      this._prevJump = this.jump;
      this._jumpPressed = false;
      this._pausePressed = false;
      this._restartPressed = false;
    }

    consumeJump() {
      if (this._jumpPressed) {
        this._jumpPressed = false;
        return true;
      }
      return false;
    }

    consumePause() {
      if (this._pausePressed) {
        this._pausePressed = false;
        return true;
      }
      return false;
    }

    consumeRestart() {
      if (this._restartPressed) {
        this._restartPressed = false;
        return true;
      }
      return false;
    }

    /* Programmatic presses from touch buttons */
    press(action, down) {
      switch (action) {
        case "LEFT":
          this.left = down;
          break;
        case "RIGHT":
          this.right = down;
          break;
        case "JUMP":
          if (down && !this.jump) this._jumpPressed = true;
          this.jump = down;
          break;
      }
    }
  }

  /* ------------------------------------------------------------------ *
   * Camera — smooth follow with deadzone, clamped to level bounds
   * ------------------------------------------------------------------ */
  class Camera {
    constructor() {
      this.x = 0;
      this.y = 0;
      this.targetX = 0;
      this.targetY = 0;
      this.viewportW = CONFIG.CANVAS_W;
      this.viewportH = CONFIG.CANVAS_H;
      this.bounds = { x: 0, y: 0, w: CONFIG.CANVAS_W, h: CONFIG.CANVAS_H };
    }

    setBounds(w, h) {
      this.bounds.w = w;
      this.bounds.h = h;
    }

    follow(target) {
      const deadzoneX = 120;
      const desiredX = target.x + target.w / 2 - this.viewportW / 2;
      if (Math.abs(desiredX - this.x) > deadzoneX) {
        this.targetX = desiredX - Math.sign(desiredX - this.x) * deadzoneX;
      }
      // vertical: keep player around 60% down the screen
      this.targetY = target.y + target.h / 2 - this.viewportH * 0.58;

      this.x = lerp(this.x, this.targetX, 0.12);
      this.y = lerp(this.y, this.targetY, 0.10);

      this.x = clamp(this.x, 0, Math.max(0, this.bounds.w - this.viewportW));
      this.y = clamp(this.y, -200, Math.max(-200, this.bounds.h - this.viewportH));
    }

    snapTo(target) {
      this.x = target.x + target.w / 2 - this.viewportW / 2;
      this.y = target.y + target.h / 2 - this.viewportH * 0.58;
      this.x = clamp(this.x, 0, Math.max(0, this.bounds.w - this.viewportW));
      this.y = clamp(this.y, -200, Math.max(-200, this.bounds.h - this.viewportH));
      this.targetX = this.x;
      this.targetY = this.y;
    }
  }

  /* ------------------------------------------------------------------ *
   * Particles
   * ------------------------------------------------------------------ */
  class Particle {
    constructor(x, y, vx, vy, life, color, size, gravity) {
      this.x = x;
      this.y = y;
      this.vx = vx;
      this.vy = vy;
      this.life = life;
      this.maxLife = life;
      this.color = color;
      this.size = size;
      this.gravity = gravity || 0;
      this.rot = rand(0, Math.PI * 2);
      this.vr = rand(-0.3, 0.3);
    }
    update() {
      this.x += this.vx;
      this.y += this.vy;
      this.vy += this.gravity;
      this.vx *= 0.96;
      this.life -= 1;
      this.rot += this.vr;
    }
    get dead() { return this.life <= 0; }
    draw(ctx, cam) {
      const t = this.life / this.maxLife;
      ctx.save();
      ctx.globalAlpha = clamp(t, 0, 1);
      ctx.translate(this.x - cam.x, this.y - cam.y);
      ctx.rotate(this.rot);
      ctx.fillStyle = this.color;
      const s = this.size * (0.5 + 0.5 * t);
      ctx.fillRect(-s / 2, -s / 2, s, s);
      ctx.restore();
    }
  }

  class ParticleSystem {
    constructor() { this.list = []; }
    add(p) { this.list.push(p); }
    update() {
      for (let i = this.list.length - 1; i >= 0; i--) {
        this.list[i].update();
        if (this.list[i].dead) this.list.splice(i, 1);
      }
    }
    draw(ctx, cam) {
      for (const p of this.list) p.draw(ctx, cam);
    }
    clear() { this.list.length = 0; }

    burst(x, y, opts) {
      const count = opts.count || 12;
      const colors = opts.colors || ["#fff"];
      const speed = opts.speed || 4;
      const life = opts.life || 30;
      const size = opts.size || 4;
      const gravity = opts.gravity || 0.15;
      for (let i = 0; i < count; i++) {
        const ang = rand(0, Math.PI * 2);
        const sp = rand(speed * 0.3, speed);
        this.add(new Particle(
          x, y,
          Math.cos(ang) * sp,
          Math.sin(ang) * sp - rand(0, 2),
          randInt(life * 0.6, life),
          choice(colors),
          rand(size * 0.6, size),
          gravity
        ));
      }
    }
  }

  /* ------------------------------------------------------------------ *
   * Player
   * ------------------------------------------------------------------ */
  class Player {
    constructor(x, y) {
      this.w = 26;
      this.h = 38;
      this.x = x;
      this.y = y;
      this.vx = 0;
      this.vy = 0;
      this.onGround = false;
      this.facing = 1;
      this.coyote = 0;
      this.jumpBuffer = 0;
      this.jumpHeld = false;
      this.animTime = 0;
      this.invuln = 0;          // invulnerability frames after hit
      this.dead = false;
      this.respawnTimer = 0;
      this.spawnX = x;
      this.spawnY = y;
      this.squash = 1;          // visual squash/stretch
      this.dustTimer = 0;
    }

    setSpawn(x, y) { this.spawnX = x; this.spawnY = y; }

    reset(x, y) {
      this.x = x;
      this.y = y;
      this.vx = 0;
      this.vy = 0;
      this.onGround = false;
      this.facing = 1;
      this.coyote = 0;
      this.jumpBuffer = 0;
      this.invuln = 0;
      this.dead = false;
      this.respawnTimer = 0;
      this.squash = 1;
    }

    update(input, level, game) {
      if (this.dead) {
        this.respawnTimer--;
        if (this.respawnTimer <= 0) {
          game.onPlayerDeathResolved();
        }
        return;
      }

      // Horizontal input
      let move = 0;
      if (input.left) move -= 1;
      if (input.right) move += 1;

      if (move !== 0) {
        this.vx += move * CONFIG.PLAYER_ACCEL;
        this.vx = clamp(this.vx, -CONFIG.PLAYER_MAX_SPEED, CONFIG.PLAYER_MAX_SPEED);
        this.facing = move;
      } else {
        this.vx *= this.onGround ? CONFIG.PLAYER_FRICTION : CONFIG.PLAYER_AIR_FRICTION;
        if (Math.abs(this.vx) < 0.05) this.vx = 0;
      }

      // Jump buffer + coyote time
      if (input.consumeJump()) {
        this.jumpBuffer = CONFIG.JUMP_BUFFER;
      }
      if (this.jumpBuffer > 0) this.jumpBuffer--;

      if (this.onGround) {
        this.coyote = CONFIG.COYOTE_TIME;
      } else if (this.coyote > 0) {
        this.coyote--;
      }

      if (this.jumpBuffer > 0 && this.coyote > 0) {
        this.vy = CONFIG.JUMP_VELOCITY;
        this.onGround = false;
        this.coyote = 0;
        this.jumpBuffer = 0;
        this.jumpHeld = true;
        this.squash = 1.3;
        Telemetry.send("JUMP_USED", { x: this.x, y: this.y });
      }

      // Variable jump height
      if (!input.jump && this.vy < 0 && this.jumpHeld) {
        this.vy *= CONFIG.JUMP_CUT;
        this.jumpHeld = false;
      }
      if (this.vy >= 0) this.jumpHeld = false;

      // Gravity
      this.vy += CONFIG.GRAVITY;
      if (this.vy > CONFIG.MAX_FALL) this.vy = CONFIG.MAX_FALL;

      // Move + collide (axis separated)
      this._moveAxis(level, this.vx, 0);
      const wasOnGround = this.onGround;
      this.onGround = false;
      this._moveAxis(level, 0, this.vy);

      if (!wasOnGround && this.onGround) {
        // landing squash
        this.squash = 0.7;
      }

      // Walk dust
      if (this.onGround && Math.abs(this.vx) > 1.5) {
        this.dustTimer--;
        if (this.dustTimer <= 0) {
          this.dustTimer = 5;
          game.particles.add(new Particle(
            this.x + this.w / 2 - this.facing * 6,
            this.y + this.h - 2,
            -this.facing * rand(0.3, 0.8),
            -rand(0.2, 0.6),
            randInt(10, 18),
            "rgba(200,210,230,0.6)",
            rand(2, 3.5),
            0.05
          ));
        }
      }

      // Fall off the world — costs a life, then death/respawn flow
      if (this.y > level.killY) {
        if (!this.dead) game.loseLife();
        this.kill(game, true);
      }

      // Invuln tick
      if (this.invuln > 0) this.invuln--;

      // Squash recovery
      this.squash = lerp(this.squash, 1, 0.18);

      // Animation
      this.animTime += Math.abs(this.vx) * 0.08 + 0.04;

      // Telemetry: player moved (throttled by game via flag)
      game._maybeSendMove(this);
    }

    _moveAxis(level, dx, dy) {
      this.x += dx;
      this.y += dy;

      // Collide against platforms
      for (const p of level.platforms) {
        if (aabb(this, p)) {
          if (dx > 0) {
            this.x = p.x - this.w;
            this.vx = 0;
          } else if (dx < 0) {
            this.x = p.x + p.w;
            this.vx = 0;
          }
          if (dy > 0) {
            this.y = p.y - this.h;
            this.vy = 0;
            this.onGround = true;
          } else if (dy < 0) {
            this.y = p.y + p.h;
            this.vy = 0;
          }
        }
      }

      // One-way platforms (only collide when falling onto them from above)
      for (const p of level.oneWayPlatforms) {
        if (aabb(this, p)) {
          if (dy > 0 && (this.y + this.h - dy) <= p.y + 2) {
            this.y = p.y - this.h;
            this.vy = 0;
            this.onGround = true;
          }
        }
      }
    }

    hurt(game) {
      if (this.invuln > 0 || this.dead) return;
      game.loseLife();
      if (game.lives <= 0) {
        // last life lost — start death sequence (no extra knockback)
        this.kill(game, false);
        return;
      }
      this.vy = -9;
      this.vx = -this.facing * 6;
      this.invuln = 90;
      this.squash = 1.25;
    }

    kill(game, instant) {
      if (this.dead) return;
      this.dead = true;
      this.vy = -10;
      this.vx = 0;
      this.respawnTimer = instant ? 50 : 70;
      game.particles.burst(this.x + this.w / 2, this.y + this.h / 2, {
        count: 20,
        colors: ["#ff5d6c", "#ffd34d", "#ffffff"],
        speed: 6,
        life: 36,
        size: 5,
        gravity: 0.2,
      });
    }

    draw(ctx, cam) {
      if (this.dead) {
        // spin & fall
        const cx = this.x + this.w / 2 - cam.x;
        const cy = this.y + this.h / 2 - cam.y;
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(this.respawnTimer * 0.3);
        ctx.globalAlpha = clamp(this.respawnTimer / 50, 0, 1);
        this._drawBody(ctx, 0, 0, 1, 1);
        ctx.restore();
        return;
      }

      // blink during invulnerability
      if (this.invuln > 0 && Math.floor(this.invuln / 4) % 2 === 0) return;

      const px = this.x - cam.x;
      const py = this.y - cam.y;
      const sx = 1 / this.squash;
      const sy = this.squash;
      this._drawBody(ctx, px + this.w / 2, py + this.h, sx, sy);
    }

    _drawBody(ctx, cx, by, sx, sy) {
      // Origin at center-bottom (feet). Player ~ 26x38
      const f = this.facing;
      ctx.save();
      ctx.translate(cx, by);
      ctx.scale(sx, sy);
      ctx.scale(f, 1);

      const run = Math.sin(this.animTime * 2);
      const inAir = !this.onGround;
      const legSwing = inAir ? (this.vy < 0 ? -3 : 3) : run * 6;

      // shadow
      ctx.fillStyle = "rgba(0,0,0,0.25)";
      ctx.beginPath();
      ctx.ellipse(0, 0, 14, 4, 0, 0, Math.PI * 2);
      ctx.fill();

      // ---- Legs ----
      ctx.fillStyle = "#3a4a8a"; // pants
      // back leg
      ctx.fillRect(-8, -10 + Math.min(0, legSwing), 6, 10 + Math.abs(legSwing * 0.4));
      // front leg
      ctx.fillRect(2, -10 - Math.min(0, legSwing), 6, 10 + Math.abs(legSwing * 0.4));
      // boots
      ctx.fillStyle = "#5a3a1a";
      ctx.fillRect(-9, -2 + Math.min(0, legSwing), 8, 3);
      ctx.fillRect(1, -2 - Math.min(0, legSwing), 8, 3);

      // ---- Body / tunic ----
      ctx.fillStyle = "#e8453c"; // red tunic
      roundRect(ctx, -10, -26, 20, 18, 4);
      ctx.fill();
      // belt
      ctx.fillStyle = "#5a3a1a";
      ctx.fillRect(-10, -14, 20, 3);
      // buckle
      ctx.fillStyle = "#ffd34d";
      ctx.fillRect(-2, -14, 4, 3);

      // ---- Cape (behind, flutters) ----
      const flutter = Math.sin(this.animTime * 3) * 2;
      ctx.fillStyle = "#2a6a9a";
      ctx.beginPath();
      ctx.moveTo(-8, -26);
      ctx.lineTo(-14 - flutter, -16);
      ctx.lineTo(-12 - flutter, -8);
      ctx.lineTo(-6, -14);
      ctx.closePath();
      ctx.fill();

      // ---- Arms ----
      ctx.fillStyle = "#e8453c";
      const armSwing = inAir ? -4 : -run * 5;
      ctx.fillRect(-12, -24 + armSwing * 0.3, 5, 12);
      ctx.fillRect(7, -24 - armSwing * 0.3, 5, 12);
      // hands
      ctx.fillStyle = "#f2c8a0";
      ctx.fillRect(-12, -13 + armSwing * 0.3, 5, 3);
      ctx.fillRect(7, -13 - armSwing * 0.3, 5, 3);

      // ---- Head ----
      ctx.fillStyle = "#f2c8a0"; // skin
      roundRect(ctx, -8, -38, 16, 14, 5);
      ctx.fill();

      // hood/hat
      ctx.fillStyle = "#2a8a4a"; // green hood
      ctx.beginPath();
      ctx.moveTo(-9, -30);
      ctx.lineTo(-9, -38);
      ctx.lineTo(9, -38);
      ctx.lineTo(9, -30);
      ctx.lineTo(8, -32);
      ctx.lineTo(-8, -32);
      ctx.closePath();
      ctx.fill();
      // hat tip
      ctx.fillStyle = "#2a8a4a";
      ctx.beginPath();
      ctx.moveTo(-2, -38);
      ctx.lineTo(6, -44);
      ctx.lineTo(2, -38);
      ctx.closePath();
      ctx.fill();
      // feather
      ctx.strokeStyle = "#ffd34d";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(4, -42);
      ctx.lineTo(8, -47);
      ctx.stroke();

      // ---- Face ----
      // eye
      ctx.fillStyle = "#1a1a2a";
      ctx.fillRect(2, -33, 3, 4);
      // eye shine
      ctx.fillStyle = "#fff";
      ctx.fillRect(3, -33, 1, 1);
      // brow
      ctx.fillStyle = "#5a3a1a";
      ctx.fillRect(1, -35, 5, 1);
      // mouth
      ctx.fillStyle = "#8a3a2a";
      ctx.fillRect(2, -28, 4, 1);

      ctx.restore();
    }
  }

  /* ------------------------------------------------------------------ *
   * Enemy — "Blobling". Patrols a platform, reverses at edges/walls.
   * Stompable from above.
   * ------------------------------------------------------------------ */
  class Enemy {
    constructor(x, y, opts) {
      opts = opts || {};
      this.w = 30;
      this.h = 26;
      this.x = x;
      this.y = y + 0;       // y is top of platform; we sit on top
      this.y = y - this.h;
      this.vx = (opts.dir || 1) * (opts.speed || 1.2);
      this.alive = true;
      this.animTime = rand(0, 10);
      this.color = opts.color || "#9a4dff";
      this.eyeColor = opts.eyeColor || "#fff";
      this.squashed = 0;
      this.deadTimer = 0;
      this.homePlatform = null;
    }

    update(level, game) {
      if (!this.alive) {
        this.deadTimer++;
        return;
      }

      this.animTime += 0.12;

      // gravity
      this.vy = (this.vy || 0) + CONFIG.GRAVITY;
      if (this.vy > CONFIG.MAX_FALL) this.vy = CONFIG.MAX_FALL;

      // move x
      this.x += this.vx;

      // wall reverse
      for (const p of level.platforms) {
        if (aabb(this, p)) {
          if (this.vx > 0) this.x = p.x - this.w;
          else this.x = p.x + p.w;
          this.vx = -this.vx;
        }
      }

      // edge detection: if no ground just ahead, reverse
      const aheadX = this.vx > 0 ? this.x + this.w + 2 : this.x - 2;
      const footY = this.y + this.h + 2;
      let groundAhead = false;
      for (const p of level.platforms) {
        if (aheadX >= p.x && aheadX <= p.x + p.w &&
            footY >= p.y && footY <= p.y + p.h + 6) {
          groundAhead = true;
          break;
        }
      }
      if (!groundAhead) this.vx = -this.vx;

      // move y
      this.y += this.vy;
      for (const p of level.platforms) {
        if (aabb(this, p)) {
          if (this.vy > 0) {
            this.y = p.y - this.h;
            this.vy = 0;
          } else {
            this.y = p.y + p.h;
            this.vy = 0;
          }
        }
      }

      // fell off world
      if (this.y > level.killY) this.alive = false;
    }

    // returns true if stomp resolved
    tryStomp(player, game) {
      if (!this.alive) return false;
      if (player.vy > 0 &&
          player.y + player.h - player.vy <= this.y + 6) {
        // stomp!
        this.alive = false;
        this.squashed = 1;
        player.vy = CONFIG.ENEMY_BOUNCE;
        player.jumpHeld = true;
        game.onEnemyDefeated(this);
        return true;
      }
      return false;
    }

    draw(ctx, cam) {
      if (!this.alive && this.deadTimer > 30) return;
      const px = this.x - cam.x;
      const py = this.y - cam.y;
      const cx = px + this.w / 2;
      const by = py + this.h;

      if (!this.alive) {
        // squashed flat, fading
        const a = clamp(1 - this.deadTimer / 30, 0, 1);
        ctx.save();
        ctx.globalAlpha = a;
        ctx.fillStyle = this.color;
        roundRect(ctx, px, by - 6, this.w, 6, 3);
        ctx.fill();
        ctx.restore();
        return;
      }

      const wobble = Math.sin(this.animTime) * 2;
      const squish = 1 + Math.sin(this.animTime * 2) * 0.06;
      ctx.save();
      ctx.translate(cx, by);
      ctx.scale(1, 1 / squish);
      ctx.scale(1, 1);

      // shadow
      ctx.fillStyle = "rgba(0,0,0,0.25)";
      ctx.beginPath();
      ctx.ellipse(0, 0, 16, 4, 0, 0, Math.PI * 2);
      ctx.fill();

      // body
      ctx.fillStyle = this.color;
      ctx.beginPath();
      ctx.moveTo(-15, 0);
      ctx.quadraticCurveTo(-15, -24 - wobble, 0, -24 - wobble);
      ctx.quadraticCurveTo(15, -24 - wobble, 15, 0);
      ctx.closePath();
      ctx.fill();

      // belly highlight
      ctx.fillStyle = "rgba(255,255,255,0.18)";
      ctx.beginPath();
      ctx.ellipse(-4, -12, 6, 8, 0, 0, Math.PI * 2);
      ctx.fill();

      // eyes
      const dir = this.vx > 0 ? 1 : -1;
      ctx.fillStyle = this.eyeColor;
      ctx.beginPath();
      ctx.arc(-4 + dir * 2, -14, 3.2, 0, Math.PI * 2);
      ctx.arc(5 + dir * 2, -14, 3.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#1a1a2a";
      ctx.beginPath();
      ctx.arc(-4 + dir * 3, -14, 1.6, 0, Math.PI * 2);
      ctx.arc(5 + dir * 3, -14, 1.6, 0, Math.PI * 2);
      ctx.fill();

      // little feet
      ctx.fillStyle = "#3a1a4a";
      ctx.fillRect(-10, -2, 7, 3);
      ctx.fillRect(3, -2, 7, 3);

      // angry brow
      ctx.strokeStyle = "rgba(0,0,0,0.4)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-7, -18);
      ctx.lineTo(-1, -16);
      ctx.moveTo(8, -18);
      ctx.lineTo(2, -16);
      ctx.stroke();

      ctx.restore();
    }
  }

  /* ------------------------------------------------------------------ *
   * Collectible — crystal. Spins, bobs, worth score + coin count.
   * ------------------------------------------------------------------ */
  class Collectible {
    constructor(x, y, opts) {
      opts = opts || {};
      this.w = 18;
      this.h = 22;
      this.x = x;
      this.y = y;
      this.baseY = y;
      this.collected = false;
      this.spin = rand(0, Math.PI * 2);
      this.value = opts.value || 100;
      this.color = opts.color || "#5dffa8";
      this.ringColor = opts.ringColor || "#b6ffe0";
    }
    update() {
      if (this.collected) return;
      this.spin += 0.08;
      this.y = this.baseY + Math.sin(this.spin * 0.8) * 3;
    }
    intersects(player) {
      if (this.collected) return false;
      return aabb(player, {
        x: this.x - 4, y: this.y - 4, w: this.w + 8, h: this.h + 8
      });
    }
    draw(ctx, cam) {
      if (this.collected) return;
      const cx = this.x + this.w / 2 - cam.x;
      const cy = this.y + this.h / 2 - cam.y;
      const sx = Math.cos(this.spin); // width squish for 3D spin

      ctx.save();
      ctx.translate(cx, cy);
      // glow
      ctx.globalAlpha = 0.35;
      ctx.fillStyle = this.ringColor;
      ctx.beginPath();
      ctx.arc(0, 0, 16, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;

      ctx.scale(Math.abs(sx) * 0.7 + 0.3, 1);
      // crystal gem
      ctx.fillStyle = this.color;
      ctx.beginPath();
      ctx.moveTo(0, -12);
      ctx.lineTo(8, -4);
      ctx.lineTo(5, 10);
      ctx.lineTo(-5, 10);
      ctx.lineTo(-8, -4);
      ctx.closePath();
      ctx.fill();
      // facets
      ctx.fillStyle = "rgba(255,255,255,0.5)";
      ctx.beginPath();
      ctx.moveTo(0, -12);
      ctx.lineTo(8, -4);
      ctx.lineTo(0, -2);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "rgba(0,0,0,0.2)";
      ctx.beginPath();
      ctx.moveTo(0, -2);
      ctx.lineTo(5, 10);
      ctx.lineTo(-5, 10);
      ctx.closePath();
      ctx.fill();
      // sparkle
      ctx.fillStyle = "#fff";
      ctx.fillRect(-1, -7, 2, 2);
      ctx.restore();
    }
  }

  /* ------------------------------------------------------------------ *
   * Goal portal — animated, glowing. Triggers level complete.
   * ------------------------------------------------------------------ */
  class Goal {
    constructor(x, y) {
      this.w = 46;
      this.h = 70;
      this.x = x;
      this.y = y - this.h;
      this.animTime = 0;
      this.reached = false;
    }
    update() { this.animTime += 0.08; }
    intersects(player) { return aabb(player, this); }
    draw(ctx, cam) {
      const px = this.x - cam.x;
      const py = this.y - cam.y;
      const cx = px + this.w / 2;
      const cy = py + this.h / 2;
      const t = this.animTime;

      ctx.save();
      // outer glow
      const glow = ctx.createRadialGradient(cx, cy, 4, cx, cy, 50);
      glow.addColorStop(0, "rgba(93,255,168,0.55)");
      glow.addColorStop(1, "rgba(93,255,168,0)");
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(cx, cy, 50, 0, Math.PI * 2);
      ctx.fill();

      // portal frame
      ctx.fillStyle = "#2a6a4a";
      roundRect(ctx, px - 4, py - 4, this.w + 8, this.h + 8, 12);
      ctx.fill();
      ctx.fillStyle = "#1a3a2a";
      roundRect(ctx, px - 2, py - 2, this.w + 4, this.h + 4, 10);
      ctx.fill();

      // swirling portal
      const swirl = ctx.createLinearGradient(px, py, px, py + this.h);
      swirl.addColorStop(0, "#5dffa8");
      swirl.addColorStop(0.5, "#2a8aff");
      swirl.addColorStop(1, "#b06aff");
      ctx.fillStyle = swirl;
      ctx.beginPath();
      ctx.ellipse(cx, cy, this.w / 2 - 2, this.h / 2 - 2, 0, 0, Math.PI * 2);
      ctx.fill();

      // swirl rings
      ctx.strokeStyle = "rgba(255,255,255,0.6)";
      ctx.lineWidth = 2;
      for (let i = 0; i < 3; i++) {
        const r = 6 + i * 6 + Math.sin(t + i) * 3;
        ctx.beginPath();
        ctx.ellipse(cx, cy, r, r * 1.6, Math.sin(t + i) * 0.3, 0, Math.PI * 2);
        ctx.stroke();
      }

      // sparkles
      for (let i = 0; i < 4; i++) {
        const ang = t * 2 + i * (Math.PI / 2);
        const r = 14 + Math.sin(t * 2 + i) * 4;
        ctx.fillStyle = "#fff";
        ctx.fillRect(cx + Math.cos(ang) * r - 1, cy + Math.sin(ang) * r * 1.4 - 1, 2, 2);
      }
      ctx.restore();
    }
  }

  /* ------------------------------------------------------------------ *
   * Level — holds platforms, one-way platforms, enemies, collectibles,
   *         goal, spawn, theme. Built from declarative level data.
   * ------------------------------------------------------------------ */
  class Level {
    constructor(data) {
      this.data = data;
      this.theme = data.theme || themes[0];
      this.width = data.width;
      this.height = data.height;
      this.killY = data.height + 200;
      this.platforms = [];
      this.oneWayPlatforms = [];
      this.enemies = [];
      this.collectibles = [];
      this.decorations = [];
      this.spawn = { x: 60, y: 0 };
      this.goal = null;
      this._build();
    }

    _build() {
      const d = this.data;
      // ground segments -> solid platforms
      for (const g of d.ground) {
        this.platforms.push({ x: g[0], y: g[1], w: g[2], h: g[3] || 40 });
      }
      // floating platforms
      for (const p of (d.platforms || [])) {
        const plt = { x: p[0], y: p[1], w: p[2], h: p[3] || 24 };
        this.platforms.push(plt);
        if (p[4] === "oneway") {
          this.oneWayPlatforms.push(plt);
          // remove from solids if oneway
          this.platforms.pop();
        }
      }
      // enemies: [x, y, dir, speed, color, eyeColor]
      for (const e of (d.enemies || [])) {
        const opts = { dir: e[2] || 1, speed: e[3] || 1.2, color: e[4], eyeColor: e[5] };
        this.enemies.push(new Enemy(e[0], e[1], opts));
      }
      // collectibles
      for (const c of (d.coins || [])) {
        this.collectibles.push(new Collectible(c[0], c[1], {
          value: c[2] || 100,
          color: c[3] || "#5dffa8",
          ringColor: c[4] || "#b6ffe0",
        }));
      }
      // spawn & goal
      this.spawn = { x: d.spawn[0], y: d.spawn[1] };
      this.goal = new Goal(d.goal[0], d.goal[1]);

      // decorations (background props) for visual richness
      this._buildDecor();
    }

    _buildDecor() {
      const decos = [];
      const groundTop = this.data.ground.map(g => ({ x: g[0], y: g[1], w: g[2] }));
      // place bushes/torch on ground tops
      for (const gt of groundTop) {
        const count = Math.floor(gt.w / 140);
        for (let i = 0; i < count; i++) {
          const x = gt.x + 40 + i * (gt.w / count) + rand(-20, 20);
          if (Math.random() < 0.5) {
            decos.push({ type: "bush", x, y: gt.y, s: rand(0.7, 1.2) });
          } else {
            decos.push({ type: "rock", x, y: gt.y, s: rand(0.6, 1.1) });
          }
        }
      }
      this.decorations = decos;
    }
  }

  /* ------------------------------------------------------------------ *
   * Level themes — color palettes for sky / hills / etc.
   * ------------------------------------------------------------------ */
  const themes = [
    { // Day meadow
      name: "day",
      skyTop: "#5db8ff",
      skyBot: "#bfe6ff",
      sun: "#fff6c8",
      far: "#7a9ad6",
      mid: "#5a8a5a",
      near: "#3a6a3a",
      ground: "#6a4a2a",
      grass: "#3aa84a",
      cloud: "#ffffff",
    },
    { // Sunset hills
      name: "sunset",
      skyTop: "#3a2a6a",
      skyBot: "#ff9a5a",
      sun: "#ffd34d",
      far: "#6a4a8a",
      mid: "#8a4a6a",
      near: "#5a2a4a",
      ground: "#4a2a3a",
      grass: "#8a5a3a",
      cloud: "#ffb088",
    },
    { // Night cavern
      name: "night",
      skyTop: "#0a0e2a",
      skyBot: "#1a2a5a",
      sun: "#dfe7ff",
      far: "#1a2a5a",
      mid: "#2a2a5a",
      near: "#1a1a3a",
      ground: "#2a1a3a",
      grass: "#4a3a6a",
      cloud: "#3a3a6a",
    },
  ];

  /* ------------------------------------------------------------------ *
   * Level data — 3 handcrafted levels of increasing difficulty.
   *   ground: [x, y, w, h]
   *   platforms: [x, y, w, h, ("oneway"?)]
   *   enemies: [x, y, dir, speed, color, eyeColor]  (y = top of platform)
   *   coins: [x, y, value, color, ringColor]
   *   spawn: [x, y]
   *   goal: [x, y]  (y = ground top)
   * ------------------------------------------------------------------ */
  const LEVELS = [
    // ---------- LEVEL 1: gentle intro ----------
    {
      title: "Sunny Meadows",
      theme: themes[0],
      width: 3200,
      height: 600,
      spawn: [60, 460],
      goal: [3060, 500],
      ground: [
        [0, 500, 700, 100],
        [820, 500, 520, 100],
        [1460, 500, 420, 100],
        [2020, 500, 560, 100],
        [2720, 500, 480, 100],
      ],
      platforms: [
        [320, 400, 120, 20],
        [520, 330, 120, 20],
        [760, 360, 100, 20, "oneway"],
        [1120, 380, 120, 20],
        [1340, 300, 120, 20],
        [1700, 380, 120, 20, "oneway"],
        [1880, 320, 100, 20],
        [2280, 380, 120, 20],
        [2480, 300, 120, 20],
        [2660, 360, 100, 20, "oneway"],
      ],
      enemies: [
        [900, 500, -1, 1.2, "#9a4dff", "#fff"],
        [1500, 500, 1, 1.3, "#9a4dff", "#fff"],
        [2200, 500, -1, 1.4, "#9a4dff", "#fff"],
        [2820, 500, 1, 1.5, "#9a4dff", "#fff"],
      ],
      coins: [
        [350, 360, 100],
        [560, 290, 100],
        [620, 290, 100],
        [790, 320, 150],
        [1160, 340, 100],
        [1380, 260, 100],
        [1420, 260, 100],
        [1740, 340, 100],
        [1920, 280, 100],
        [2320, 340, 100],
        [2520, 260, 100],
        [2560, 260, 100],
        [2700, 320, 150],
        [1000, 460, 100],
        [1640, 460, 100],
      ],
    },

    // ---------- LEVEL 2: sunset, longer gaps, more enemies ----------
    {
      title: "Sunset Ridge",
      theme: themes[1],
      width: 3800,
      height: 620,
      spawn: [60, 480],
      goal: [3660, 520],
      ground: [
        [0, 520, 560, 120],
        [680, 520, 420, 120],
        [1240, 520, 360, 120],
        [1760, 520, 420, 120],
        [2320, 520, 360, 120],
        [2820, 520, 460, 120],
        [3420, 520, 380, 120],
      ],
      platforms: [
        [280, 420, 110, 18],
        [460, 350, 100, 18, "oneway"],
        [620, 380, 100, 18, "oneway"],
        [860, 400, 120, 18],
        [1080, 330, 120, 18],
        [1300, 400, 100, 18, "oneway"],
        [1500, 340, 120, 18],
        [1820, 400, 120, 18],
        [2020, 330, 100, 18, "oneway"],
        [2200, 360, 100, 18, "oneway"],
        [2400, 390, 120, 18],
        [2600, 310, 120, 18],
        [2900, 400, 120, 18, "oneway"],
        [3080, 330, 120, 18],
        [3300, 380, 120, 18, "oneway"],
      ],
      enemies: [
        [760, 520, -1, 1.4, "#ff6a4d", "#fff"],
        [1300, 520, 1, 1.5, "#ff6a4d", "#fff"],
        [1820, 520, -1, 1.5, "#ff6a4d", "#fff"],
        [2400, 520, 1, 1.6, "#ff6a4d", "#fff"],
        [2900, 520, -1, 1.7, "#ff6a4d", "#fff"],
        [3500, 520, 1, 1.8, "#ff6a4d", "#fff"],
      ],
      coins: [
        [310, 380, 100],
        [490, 310, 100],
        [660, 340, 150],
        [900, 360, 100],
        [1120, 290, 100],
        [1160, 290, 100],
        [1340, 360, 150],
        [1540, 300, 100],
        [1860, 360, 100],
        [2060, 290, 150],
        [2240, 320, 100],
        [2440, 350, 100],
        [2640, 270, 100],
        [2680, 270, 100],
        [2940, 360, 150],
        [3120, 290, 100],
        [3160, 290, 100],
        [3340, 340, 150],
        [800, 480, 100],
        [1860, 480, 100],
      ],
    },

    // ---------- LEVEL 3: night, tight jumps, many enemies ----------
    {
      title: "Midnight Caverns",
      theme: themes[2],
      width: 4400,
      height: 640,
      spawn: [60, 500],
      goal: [4260, 540],
      ground: [
        [0, 540, 480, 140],
        [600, 540, 320, 140],
        [1080, 540, 280, 140],
        [1520, 540, 320, 140],
        [2000, 540, 280, 140],
        [2440, 540, 320, 140],
        [2920, 540, 280, 140],
        [3360, 540, 360, 140],
        [3860, 540, 540, 140],
      ],
      platforms: [
        [240, 440, 90, 16, "oneway"],
        [400, 370, 90, 16],
        [540, 420, 90, 16, "oneway"],
        [760, 400, 90, 16],
        [920, 330, 90, 16],
        [1140, 410, 90, 16, "oneway"],
        [1320, 340, 90, 16],
        [1560, 410, 90, 16, "oneway"],
        [1740, 350, 90, 16],
        [1900, 290, 90, 16],
        [2060, 410, 90, 16, "oneway"],
        [2240, 340, 90, 16],
        [2480, 410, 90, 16, "oneway"],
        [2660, 330, 90, 16],
        [2840, 380, 90, 16, "oneway"],
        [3020, 310, 90, 16],
        [3200, 390, 90, 16, "oneway"],
        [3400, 320, 100, 16],
        [3620, 400, 100, 16, "oneway"],
        [3820, 330, 100, 16],
        [4040, 400, 100, 16, "oneway"],
      ],
      enemies: [
        [680, 540, -1, 1.6, "#6a3aff", "#b6d0ff"],
        [1120, 540, 1, 1.7, "#6a3aff", "#b6d0ff"],
        [1560, 540, -1, 1.7, "#6a3aff", "#b6d0ff"],
        [2080, 540, 1, 1.8, "#6a3aff", "#b6d0ff"],
        [2520, 540, -1, 1.8, "#6a3aff", "#b6d0ff"],
        [3000, 540, 1, 1.9, "#6a3aff", "#b6d0ff"],
        [3440, 540, -1, 1.9, "#6a3aff", "#b6d0ff"],
        [3920, 540, 1, 2.0, "#6a3aff", "#b6d0ff"],
      ],
      coins: [
        [270, 400, 150],
        [430, 330, 100],
        [570, 380, 150],
        [790, 360, 100],
        [950, 290, 100],
        [990, 290, 100],
        [1170, 370, 150],
        [1350, 300, 100],
        [1390, 300, 100],
        [1590, 370, 150],
        [1770, 310, 100],
        [1930, 250, 150],
        [2090, 370, 150],
        [2270, 300, 100],
        [2310, 300, 100],
        [2510, 370, 150],
        [2690, 290, 100],
        [2730, 290, 100],
        [2870, 340, 150],
        [3050, 270, 150],
        [3230, 350, 150],
        [3430, 280, 150],
        [3490, 280, 150],
        [3650, 360, 150],
        [3850, 290, 150],
        [3890, 290, 150],
        [4070, 360, 150],
        [700, 500, 100],
        [2000, 500, 100],
        [3900, 500, 100],
      ],
    },
  ];

  /* ------------------------------------------------------------------ *
   * Renderer — background parallax + world + entities + foreground fx
   * ------------------------------------------------------------------ */
  class Renderer {
    constructor(canvas) {
      this.canvas = canvas;
      this.ctx = canvas.getContext("2d");
      this.ctx.imageSmoothingEnabled = false;
      this.starField = this._makeStars(80);
      this.cloudField = this._makeClouds(8);
      this.time = 0;
    }

    _makeStars(n) {
      const arr = [];
      for (let i = 0; i < n; i++) {
        arr.push({
          x: rand(0, CONFIG.CANVAS_W),
          y: rand(0, CONFIG.CANVAS_H * 0.6),
          r: rand(0.5, 1.8),
          tw: rand(0, Math.PI * 2),
        });
      }
      return arr;
    }
    _makeClouds(n) {
      const arr = [];
      for (let i = 0; i < n; i++) {
        arr.push({
          x: rand(0, 3200),
          y: rand(40, 180),
          s: rand(0.6, 1.4),
          spd: rand(0.1, 0.3),
        });
      }
      return arr;
    }

    clear(theme) {
      const g = this.ctx.createLinearGradient(0, 0, 0, CONFIG.CANVAS_H);
      g.addColorStop(0, theme.skyTop);
      g.addColorStop(1, theme.skyBot);
      this.ctx.fillStyle = g;
      this.ctx.fillRect(0, 0, CONFIG.CANVAS_W, CONFIG.CANVAS_H);
    }

    drawBackground(cam, theme) {
      const ctx = this.ctx;
      this.time += 0.016;

      // Sun / moon
      const sunX = CONFIG.CANVAS_W * 0.78;
      const sunY = CONFIG.CANVAS_H * 0.22;
      const glow = ctx.createRadialGradient(sunX, sunY, 4, sunX, sunY, 120);
      glow.addColorStop(0, theme.sun);
      glow.addColorStop(1, "rgba(255,255,255,0)");
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(sunX, sunY, 120, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = theme.sun;
      ctx.beginPath();
      ctx.arc(sunX, sunY, 34, 0, Math.PI * 2);
      ctx.fill();

      // Stars (night theme)
      if (theme.name === "night") {
        for (const s of this.starField) {
          const a = 0.4 + 0.6 * (0.5 + 0.5 * Math.sin(this.time * 2 + s.tw));
          ctx.globalAlpha = a;
          ctx.fillStyle = "#dfe7ff";
          ctx.fillRect(s.x, s.y, s.r, s.r);
        }
        ctx.globalAlpha = 1;
      }

      // Clouds (day/sunset)
      if (theme.name !== "night") {
        for (const c of this.cloudField) {
          c.x += c.spd;
          if (c.x > 3300) c.x = -100;
          const x = c.x - cam.x * 0.25;
          this._drawCloud(x % 3300, c.y, c.s, theme.cloud);
        }
      }

      // Parallax far hills
      this._drawHills(cam.x * 0.2, 360, theme.far, 90, 220);
      // Mid hills
      this._drawHills(cam.x * 0.4, 420, theme.mid, 70, 180);
      // Near trees silhouettes
      this._drawTrees(cam.x * 0.6, 470, theme.near);
    }

    _drawCloud(x, y, s, color) {
      const ctx = this.ctx;
      ctx.fillStyle = color;
      ctx.globalAlpha = 0.9;
      ctx.beginPath();
      ctx.arc(x, y, 18 * s, 0, Math.PI * 2);
      ctx.arc(x + 20 * s, y + 4 * s, 14 * s, 0, Math.PI * 2);
      ctx.arc(x - 18 * s, y + 4 * s, 12 * s, 0, Math.PI * 2);
      ctx.arc(x + 4 * s, y - 8 * s, 12 * s, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }

    _drawHills(offset, baseY, color, amp, period) {
      const ctx = this.ctx;
      ctx.fillStyle = color;
      ctx.beginPath();
      ctx.moveTo(0, CONFIG.CANVAS_H);
      const phase = -offset % period;
      for (let x = -period; x <= CONFIG.CANVAS_W + period; x += 8) {
        const wx = x + phase;
        const y = baseY + Math.sin((wx) / period * Math.PI * 2) * amp * 0.5
                + Math.sin((wx) / (period * 0.5) * Math.PI * 2) * amp * 0.25;
        ctx.lineTo(x, y);
      }
      ctx.lineTo(CONFIG.CANVAS_W, CONFIG.CANVAS_H);
      ctx.closePath();
      ctx.fill();
    }

    _drawTrees(offset, baseY, color) {
      const ctx = this.ctx;
      ctx.fillStyle = color;
      const spacing = 160;
      const phase = (-offset % spacing);
      for (let i = -1; i < CONFIG.CANVAS_W / spacing + 2; i++) {
        const x = i * spacing + phase + (i * 53) % 40;
        const h = 60 + (i * 37) % 30;
        // trunk
        ctx.fillStyle = "#3a2a1a";
        ctx.fillRect(x - 4, baseY - h * 0.4, 8, h * 0.4);
        // foliage
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.moveTo(x, baseY - h);
        ctx.lineTo(x - 22, baseY - h * 0.4);
        ctx.lineTo(x + 22, baseY - h * 0.4);
        ctx.closePath();
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(x, baseY - h * 0.7);
        ctx.lineTo(x - 18, baseY - h * 0.2);
        ctx.lineTo(x + 18, baseY - h * 0.2);
        ctx.closePath();
        ctx.fill();
      }
    }

    drawWorld(level, cam, theme) {
      const ctx = this.ctx;

      // Decorations (behind platforms)
      for (const d of level.decorations) {
        const x = d.x - cam.x;
        const y = d.y - cam.y;
        if (x < -60 || x > CONFIG.CANVAS_W + 60) continue;
        if (d.type === "bush") {
          ctx.fillStyle = "#2a8a3a";
          ctx.beginPath();
          ctx.arc(x, y, 12 * d.s, 0, Math.PI * 2);
          ctx.arc(x + 12 * d.s, y, 10 * d.s, 0, Math.PI * 2);
          ctx.arc(x - 10 * d.s, y, 9 * d.s, 0, Math.PI * 2);
          ctx.fill();
        } else {
          ctx.fillStyle = "#6a6a7a";
          ctx.beginPath();
          ctx.ellipse(x, y, 10 * d.s, 6 * d.s, 0, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Platforms
      for (const p of level.platforms) {
        this._drawPlatform(p, cam, theme, false);
      }
      for (const p of level.oneWayPlatforms) {
        this._drawPlatform(p, cam, theme, true);
      }

      // Collectibles
      for (const c of level.collectibles) c.draw(ctx, cam);

      // Goal portal
      level.goal.draw(ctx, cam);

      // Enemies
      for (const e of level.enemies) e.draw(ctx, cam);

      // Player
      level._player && level._player.draw(ctx, cam);
    }

    _drawPlatform(p, cam, theme, oneway) {
      const ctx = this.ctx;
      const x = p.x - cam.x;
      const y = p.y - cam.y;
      // body
      ctx.fillStyle = theme.ground;
      ctx.fillRect(x, y, p.w, p.h);
      // dirt texture lines
      ctx.fillStyle = "rgba(0,0,0,0.18)";
      for (let i = 8; i < p.w; i += 22) {
        ctx.fillRect(x + i, y + 10, 3, 3);
      }
      for (let i = 16; i < p.w; i += 26) {
        ctx.fillRect(x + i, y + 22, 2, 3);
      }
      // grass top
      if (!oneway) {
        ctx.fillStyle = theme.grass;
        ctx.fillRect(x, y, p.w, 6);
        // grass blades
        ctx.fillStyle = "rgba(255,255,255,0.18)";
        for (let i = 4; i < p.w; i += 10) {
          ctx.fillRect(x + i, y - 2, 2, 3);
        }
        // edge shadow
        ctx.fillStyle = "rgba(0,0,0,0.25)";
        ctx.fillRect(x, y + 6, p.w, 2);
      } else {
        // one-way platform: thin plank
        ctx.fillStyle = theme.grass;
        ctx.fillRect(x, y, p.w, 4);
        ctx.fillStyle = "rgba(0,0,0,0.3)";
        ctx.fillRect(x, y + 4, p.w, 2);
      }
    }
  }

  /* ------------------------------------------------------------------ *
   * UI manager — DOM-based HUD + overlay screens
   * ------------------------------------------------------------------ */
  class UI {
    constructor() {
      this.hud = document.getElementById("hud");
      this.scoreEl = document.getElementById("hud-score");
      this.coinsEl = document.getElementById("hud-coins");
      this.livesEl = document.getElementById("hud-lives");
      this.levelEl = document.getElementById("hud-level");

      this.startScreen = document.getElementById("start-screen");
      this.pauseScreen = document.getElementById("pause-screen");
      this.levelCompleteScreen = document.getElementById("level-complete-screen");
      this.winScreen = document.getElementById("win-screen");
      this.gameOverScreen = document.getElementById("game-over-screen");
      this.touchControls = document.getElementById("touch-controls");
      this.flash = document.getElementById("flash");

      this.lcScore = document.getElementById("lc-score");
      this.lcCoins = document.getElementById("lc-coins");
      this.lcLevel = document.getElementById("lc-level");
      this.winScore = document.getElementById("win-score");
      this.winCoins = document.getElementById("win-coins");
      this.goScore = document.getElementById("go-score");
      this.goCoins = document.getElementById("go-coins");
      this.goLevel = document.getElementById("go-level");
    }

    showHud(show) { this.hud.classList.toggle("hidden", !show); }
    setScore(v) { this._set(this.scoreEl, v); }
    setCoins(v) { this._set(this.coinsEl, v); }
    setLives(v) { this._set(this.livesEl, v); }
    setLevel(v) { this._set(this.levelEl, v); }

    _set(el, v) {
      if (el.textContent != v) {
        el.textContent = v;
        el.classList.remove("bump");
        // reflow to restart animation
        void el.offsetWidth;
        el.classList.add("bump");
      }
    }

    showScreen(name) {
      this.startScreen.classList.add("hidden");
      this.pauseScreen.classList.add("hidden");
      this.levelCompleteScreen.classList.add("hidden");
      this.winScreen.classList.add("hidden");
      this.gameOverScreen.classList.add("hidden");
      switch (name) {
        case "start": this.startScreen.classList.remove("hidden"); break;
        case "pause": this.pauseScreen.classList.remove("hidden"); break;
        case "level_complete": this.levelCompleteScreen.classList.remove("hidden"); break;
        case "win": this.winScreen.classList.remove("hidden"); break;
        case "game_over": this.gameOverScreen.classList.remove("hidden"); break;
      }
    }

    setLevelComplete(score, coins, level) {
      this.lcScore.textContent = score;
      this.lcCoins.textContent = coins;
      this.lcLevel.textContent = level;
    }
    setWin(score, coins) {
      this.winScore.textContent = score;
      this.winCoins.textContent = coins;
    }
    setGameOver(score, coins, level) {
      this.goScore.textContent = score;
      this.goCoins.textContent = coins;
      this.goLevel.textContent = level;
    }

    showTouch(show) {
      this.touchControls.classList.toggle("hidden", !show);
      if (show) this.touchControls.classList.add("always-on");
    }

    flashScreen() {
      this.flash.classList.remove("show");
      void this.flash.offsetWidth;
      this.flash.classList.add("show");
    }
  }

  /* ------------------------------------------------------------------ *
   * Small canvas helper: rounded rect
   * ------------------------------------------------------------------ */
  function roundRect(ctx, x, y, w, h, r) {
    r = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  /* ------------------------------------------------------------------ *
   * Game — main controller & state machine
   * ------------------------------------------------------------------ */
  class Game {
    constructor() {
      this.canvas = document.getElementById("game-canvas");
      this.input = new InputManager();
      this.camera = new Camera();
      this.particles = new ParticleSystem();
      this.renderer = new Renderer(this.canvas);
      this.ui = new UI();

      this.state = STATE.BOOT;
      this.levelIndex = 0;
      this.level = null;
      this.player = null;

      this.score = 0;
      this.coins = 0;
      this.lives = CONFIG.START_LIVES;
      this.totalCoinsAllLevels = 0;

      this._lastMoveTelemetry = 0;
      this._moveTelemetryAccum = 0;

      this._accumulator = 0;
      this._lastTime = 0;

      this._fitCanvas();
      window.addEventListener("resize", () => this._fitCanvas());

      this._bindUI();
      this._bindTouch();

      // Show touch controls if touch device
      this.ui.showTouch(this.input.hasTouch);

      this._setState(STATE.START);
      this._lastTime = performance.now();
      requestAnimationFrame((t) => this._loop(t));
    }

    _fitCanvas() {
      // Keep internal resolution at 960x540 (16:9), scale via CSS.
      const ratio = CONFIG.CANVAS_W / CONFIG.CANVAS_H;
      let w = window.innerWidth;
      let h = window.innerHeight;
      if (w / h > ratio) w = h * ratio;
      else h = w / ratio;
      this.canvas.style.width = w + "px";
      this.canvas.style.height = h + "px";
    }

    _bindUI() {
      document.getElementById("start-btn").addEventListener("click", () => this.startGame());
      document.getElementById("resume-btn").addEventListener("click", () => this.togglePause());
      document.getElementById("restart-btn-pause").addEventListener("click", () => this.startGame());
      document.getElementById("next-btn").addEventListener("click", () => this.nextLevel());
      document.getElementById("play-again-btn").addEventListener("click", () => this.startGame());
      document.getElementById("retry-btn").addEventListener("click", () => this.startGame());
    }

    _bindTouch() {
      const bind = (id, action) => {
        const el = document.getElementById(id);
        const down = (e) => {
          e.preventDefault();
          el.classList.add("pressed");
          this.input.press(action, true);
        };
        const up = (e) => {
          e.preventDefault();
          el.classList.remove("pressed");
          this.input.press(action, false);
        };
        el.addEventListener("touchstart", down, { passive: false });
        el.addEventListener("touchend", up, { passive: false });
        el.addEventListener("touchcancel", up, { passive: false });
        el.addEventListener("mousedown", down);
        el.addEventListener("mouseup", up);
        el.addEventListener("mouseleave", up);
      };
      bind("btn-left", "LEFT");
      bind("btn-right", "RIGHT");
      bind("btn-jump", "JUMP");
    }

    /* ---------- State transitions ---------- */
    _setState(s) {
      this.state = s;
      this.ui.showHud(s === STATE.PLAYING || s === STATE.PAUSED);
      switch (s) {
        case STATE.START: this.ui.showScreen("start"); break;
        case STATE.PAUSED: this.ui.showScreen("pause"); break;
        case STATE.LEVEL_COMPLETE: this.ui.showScreen("level_complete"); break;
        case STATE.WIN: this.ui.showScreen("win"); break;
        case STATE.GAME_OVER: this.ui.showScreen("game_over"); break;
        case STATE.PLAYING: this.ui.showScreen(null); break;
      }
    }

    startGame() {
      this.levelIndex = 0;
      this.score = 0;
      this.coins = 0;
      this.totalCoinsAllLevels = 0;
      this.lives = CONFIG.START_LIVES;
      this._loadLevel(0);
      this._setState(STATE.PLAYING);
      this.ui.setScore(this.score);
      this.ui.setCoins(this.coins);
      this.ui.setLives(this.lives);
      this.ui.setLevel(this.levelIndex + 1);
      Telemetry.send("GAME_STARTED", {
        level: this.levelIndex + 1,
        lives: this.lives,
      });
    }

    _loadLevel(idx) {
      const data = LEVELS[idx];
      this.level = new Level(data);
      this.player = new Player(this.level.spawn.x, this.level.spawn.y);
      this.player.setSpawn(this.level.spawn.x, this.level.spawn.y);
      this.level._player = this.player;
      this.camera.setBounds(this.level.width, this.level.height);
      this.camera.snapTo(this.player);
      this.particles.clear();
      this._levelIntroT = 0;
    }

    nextLevel() {
      this.levelIndex++;
      if (this.levelIndex >= LEVELS.length) {
        this._setState(STATE.WIN);
        this.ui.setWin(this.score, this.coins);
        return;
      }
      this._loadLevel(this.levelIndex);
      this._setState(STATE.PLAYING);
      this.ui.setLevel(this.levelIndex + 1);
    }

    togglePause() {
      if (this.state === STATE.PLAYING) this._setState(STATE.PAUSED);
      else if (this.state === STATE.PAUSED) this._setState(STATE.PLAYING);
    }

    restart() {
      this.startGame();
    }

    /* ---------- Game events ---------- */
    loseLife() {
      if (this.lives <= 0) return;
      this.lives--;
      this.ui.setLives(this.lives);
      this.ui.flashScreen();
      Telemetry.send("PLAYER_DIED", { lives: this.lives, score: this.score });
    }

    onPlayerDeathResolved() {
      if (this.lives <= 0) {
        Telemetry.send("GAME_OVER", { score: this.score, coins: this.coins });
        this.ui.setGameOver(this.score, this.coins, this.levelIndex + 1);
        this._setState(STATE.GAME_OVER);
      } else {
        // respawn at spawn point
        this.player.reset(this.player.spawnX, this.player.spawnY);
        this.camera.snapTo(this.player);
      }
    }

    onEnemyDefeated(enemy) {
      this.score += 200;
      this.ui.setScore(this.score);
      this.particles.burst(enemy.x + enemy.w / 2, enemy.y + enemy.h / 2, {
        count: 16,
        colors: ["#ff6a4d", "#ffd34d", "#ffffff", enemy.color],
        speed: 5,
        life: 30,
        size: 4,
        gravity: 0.2,
      });
      Telemetry.send("ENEMY_DEFEATED", {
        score: this.score,
        x: enemy.x,
        y: enemy.y,
      });
      this._sendScoreUpdate();
    }

    onCoinCollected(c) {
      this.score += c.value;
      this.coins++;
      this.totalCoinsAllLevels++;
      this.ui.setScore(this.score);
      this.ui.setCoins(this.coins);
      this.particles.burst(c.x + c.w / 2, c.y + c.h / 2, {
        count: 14,
        colors: ["#5dffa8", "#b6ffe0", "#ffffff", c.color],
        speed: 4,
        life: 26,
        size: 4,
        gravity: 0.1,
      });
      Telemetry.send("COIN_COLLECTED", {
        totalCoins: this.coins,
        score: this.score,
      });
      this._sendScoreUpdate();
    }

    onLevelCompleted() {
      // bonus for remaining lives
      const bonus = this.lives * 500;
      this.score += bonus;
      this.ui.setScore(this.score);
      Telemetry.send("LEVEL_COMPLETED", {
        level: this.levelIndex + 1,
        score: this.score,
        coins: this.coins,
        bonus: bonus,
      });
      this._sendScoreUpdate();
      this.ui.setLevelComplete(this.score, this.coins, this.levelIndex + 1);
      this._setState(STATE.LEVEL_COMPLETE);
    }

    _sendScoreUpdate() {
      Telemetry.send("SCORE_UPDATED", { score: this.score, coins: this.coins });
    }

    _maybeSendMove(player) {
      // throttle to ~ every 0.5s and only when actually moving
      this._moveTelemetryAccum++;
      if (this._moveTelemetryAccum >= 30 &&
          (Math.abs(player.vx) > 0.5 || Math.abs(player.vy) > 0.5)) {
        this._moveTelemetryAccum = 0;
        Telemetry.send("PLAYER_MOVED", {
          x: Math.round(player.x),
          y: Math.round(player.y),
          vx: Math.round(player.vx * 100) / 100,
          vy: Math.round(player.vy * 100) / 100,
        });
      }
    }

    /* ---------- Main loop ---------- */
    _loop(now) {
      const dt = Math.min(now - this._lastTime, CONFIG.MAX_FRAME_DELTA);
      this._lastTime = now;

      // Handle meta input edges regardless of state
      if (this.input.consumeRestart()) {
        if (this.state === STATE.PLAYING || this.state === STATE.PAUSED ||
            this.state === STATE.GAME_OVER || this.state === STATE.WIN) {
          this.restart();
        }
      }
      if (this.input.consumePause()) {
        if (this.state === STATE.PLAYING || this.state === STATE.PAUSED) {
          this.togglePause();
        }
      }

      if (this.state === STATE.PLAYING) {
        this._accumulator += dt;
        let steps = 0;
        while (this._accumulator >= CONFIG.FIXED_DT && steps < 5) {
          this._fixedUpdate();
          this._accumulator -= CONFIG.FIXED_DT;
          steps++;
        }
        // drop residual if we capped (prevents spiral of death)
        if (steps >= 5) this._accumulator = 0;
      }

      this._render();
      this.input.postUpdate();
      requestAnimationFrame((t) => this._loop(t));
    }

    _fixedUpdate() {
      const lvl = this.level;
      const p = this.player;

      p.update(this.input, lvl, this);

      // Update enemies
      for (const e of lvl.enemies) e.update(lvl, this);

      // Collectibles
      for (const c of lvl.collectibles) {
        c.update();
        if (c.intersects(p)) {
          c.collected = true;
          this.onCoinCollected(c);
        }
      }

      // Enemy collisions
      for (const e of lvl.enemies) {
        if (!e.alive) continue;
        if (aabb(p, e)) {
          if (!e.tryStomp(p, this)) {
            // side hit -> player hurt
            p.hurt(this);
          }
        }
      }

      // Goal
      lvl.goal.update();
      if (!lvl.goal.reached && lvl.goal.intersects(p)) {
        lvl.goal.reached = true;
        this.onLevelCompleted();
      }

      // Particles
      this.particles.update();

      // Camera
      this.camera.follow(p);
    }

    _render() {
      const ctx = this.renderer.ctx;
      const theme = this.level ? this.level.theme : themes[0];

      this.renderer.clear(theme);
      this.renderer.drawBackground(this.camera, theme);

      if (this.level) {
        this.renderer.drawWorld(this.level, this.camera, theme);
        this.particles.draw(ctx, this.camera);
      }

      // Vignette overlay for polish
      this._drawVignette(ctx);

      // Level title flash at start of level
      this._drawLevelIntro(ctx);
    }

    _drawVignette(ctx) {
      const g = ctx.createRadialGradient(
        CONFIG.CANVAS_W / 2, CONFIG.CANVAS_H / 2, 200,
        CONFIG.CANVAS_W / 2, CONFIG.CANVAS_H / 2, 600
      );
      g.addColorStop(0, "rgba(0,0,0,0)");
      g.addColorStop(1, "rgba(0,0,0,0.35)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, CONFIG.CANVAS_W, CONFIG.CANVAS_H);
    }

    _drawLevelIntro(ctx) {
      if (!this.level) return;
      if (!this._levelIntroT) this._levelIntroT = 0;
      this._levelIntroT += 0.016;
      if (this._levelIntroT > 2.6) return;
      const t = this._levelIntroT;
      let a = 1;
      if (t < 0.4) a = t / 0.4;
      else if (t > 2.0) a = (2.6 - t) / 0.6;
      a = clamp(a, 0, 1);
      ctx.save();
      ctx.globalAlpha = a;
      ctx.textAlign = "center";
      ctx.fillStyle = "rgba(0,0,0,0.5)";
      ctx.fillRect(0, CONFIG.CANVAS_H * 0.4, CONFIG.CANVAS_W, 80);
      ctx.fillStyle = "#ffd34d";
      ctx.font = "900 30px 'Trebuchet MS', sans-serif";
      ctx.fillText(`LEVEL ${this.levelIndex + 1}`, CONFIG.CANVAS_W / 2, CONFIG.CANVAS_H * 0.4 + 35);
      ctx.fillStyle = "#ffffff";
      ctx.font = "700 22px 'Trebuchet MS', sans-serif";
      ctx.fillText(this.level.data.title || "", CONFIG.CANVAS_W / 2, CONFIG.CANVAS_H * 0.4 + 62);
      ctx.restore();
    }
  }

  /* ------------------------------------------------------------------ *
   * Boot
   * ------------------------------------------------------------------ */
  window.addEventListener("load", () => {
    window.__game = new Game();
  });
})();
